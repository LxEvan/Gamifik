import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistroAlumnoComponentComponent } from './registro-alumno-component.component';

describe('RegistroAlumnoComponentComponent', () => {
  let component: RegistroAlumnoComponentComponent;
  let fixture: ComponentFixture<RegistroAlumnoComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegistroAlumnoComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistroAlumnoComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
