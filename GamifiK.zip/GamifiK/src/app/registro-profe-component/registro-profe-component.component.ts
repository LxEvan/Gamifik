import { Component, OnInit } from '@angular/core';
import { LoginService } from "../login-services/login-services.service";

@Component({
  selector: 'app-registro-profe-component',
  templateUrl: './registro-profe-component.component.html',
  styleUrls: ['./registro-profe-component.component.css']
})
export class RegistroProfeComponentComponent implements OnInit {
  
  email: string;
  password: string;
  confirmPassword: string;
  passwordError: boolean;

  constructor(public LoginService: LoginService) { }

  ngOnInit(): void {
  }

  register() {
    const user = { email: this.email, password: this.password };
    this.LoginService.register(user).subscribe(data => {
      this.LoginService.setToken(data.token);
    });
  }
}
