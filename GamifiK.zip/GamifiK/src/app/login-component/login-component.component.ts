import { Component, OnInit } from '@angular/core';
import { LoginService } from "../login-services/login-services.service";

@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',
  styleUrls: ['./login-component.component.css']
})
export class LoginComponentComponent implements OnInit {
  email: string;
  password: string;

  constructor(public LoginService: LoginService) { }

  login() {
    const user = { email: this.email, password: this.password };
    this.LoginService.login(user).subscribe(data => {
      this.LoginService.setToken(data.token);
    });
  }
  ngOnInit(): void {
  }

}
