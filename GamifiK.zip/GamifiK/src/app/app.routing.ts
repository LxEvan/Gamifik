import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { RegistroProfeComponentComponent } from './registro-profe-component/registro-profe-component.component';
import { RegistroAlumnoComponentComponent } from './registro-alumno-component/registro-alumno-component.component';
import { LoginComponentComponent } from './login-component/login-component.component';

const appRoutes = [
  { path: "", component: AppComponent, pathMatch: "full" },
  { path: 'registro-profe-component', component: RegistroProfeComponentComponent,  pathMatch: 'full'},
  { path: 'registro-alumno-component', component: RegistroAlumnoComponentComponent,  pathMatch: 'full'},
  { path: 'login-component', component: LoginComponentComponent,  pathMatch: 'full'}, 
];
export const routing = RouterModule.forRoot(appRoutes);