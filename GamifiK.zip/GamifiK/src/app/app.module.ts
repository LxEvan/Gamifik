import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CookieService } from 'ngx-cookie-service';
import { LoginComponentComponent } from './login-component/login-component.component';
import { RegistroProfeComponentComponent } from './registro-profe-component/registro-profe-component.component';
import { RegistroAlumnoComponentComponent } from './registro-alumno-component/registro-alumno-component.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponentComponent,
    RegistroProfeComponentComponent,
    RegistroAlumnoComponentComponent
  ],
  imports: [
    RouterModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [CookieService],
  bootstrap: [AppComponent]
})
export class AppModule { }
