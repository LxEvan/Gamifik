<?php
header("Access-Control-Allow-Origin: http://localhost:4200");
if (empty($_GET["idUsuarios"])) {
    exit("No hay id de usuario");
}
$idUsuarios = $_GET["idUsuarios"];
$bd = include_once "bd.php";
$sentencia = $bd->prepare("select id, nombre, password, email from usuarios where id = ?");
$sentencia->execute([$idUsuarios]);
$usuarios = $sentencia->fetchObject();
echo json_encode($usuarios);