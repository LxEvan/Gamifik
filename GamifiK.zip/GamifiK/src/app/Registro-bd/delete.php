<?php
header("Access-Control-Allow-Origin: http://localhost:4200");
header("Access-Control-Allow-Methods: DELETE");
$metodo = $_SERVER["REQUEST_METHOD"];
if ($metodo != "DELETE" && $metodo != "OPTIONS") {
    exit("Solo se permite método DELETE");
}

if (empty($_GET["idUsuarios"])) {
    exit("No hay id de usuario para eliminar");
}
$idUsuarios = $_GET["idUsuarios"];
$bd = include_once "bd.php";
$sentencia = $bd->prepare("DELETE FROM usuarios WHERE id = ?");
$resultado = $sentencia->execute([$idUsuarios]);
echo json_encode($resultado);