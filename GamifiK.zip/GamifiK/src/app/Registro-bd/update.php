<?php
header("Access-Control-Allow-Origin: http://localhost:4200");
header("Access-Control-Allow-Methods: PUT");
header("Access-Control-Allow-Headers: *");
if ($_SERVER["REQUEST_METHOD"] != "PUT") {
    exit("Solo acepto peticiones PUT");
}
$jsonUsuarios = json_decode(file_get_contents("php://input"));
if (!$jsonUsuarios) {
    exit("No hay datos");
}
$bd = include_once "bd.php";
$sentencia = $bd->prepare("UPDATE usuarios SET nombre = ?, password = ?, email = ? WHERE id = ?");
$resultado = $sentencia->execute([$jsonUsuarios->nombre, $jsonUsuarios->password, $jsonUsuarios->email, $jsonUsuarios->id]);
echo json_encode($resultado);