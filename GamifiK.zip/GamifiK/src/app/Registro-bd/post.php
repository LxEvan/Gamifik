<?php
header("Access-Control-Allow-Origin: http://localhost:4200");
header("Access-Control-Allow-Headers: *");
$jsonUsuarios = json_decode(file_get_contents("php://input"));
if (!$jsonUsuarios) {
    exit("No hay datos");
}
$bd = include_once "bd.php";
$sentencia = $bd->prepare("insert into usuarios(id,nombre,password,email) values ('',?,?,?)");
$resultado = $sentencia->execute([$jsonUsuarios->nombre, $jsonUsuarios->password, $jsonUsuarios->email]);
echo json_encode([
    "resultado" => $resultado,
]);