import { Component, OnInit } from '@angular/core';
import { LoginService } from "../services/login-services.service";

@Component({
  selector: 'app-registro-alumno-component',
  templateUrl: './registro-alumno-component.component.html',
  styleUrls: ['./registro-alumno-component.component.css']
})
export class RegistroAlumnoComponentComponent implements OnInit {

  email: string;
  password: string;
  confirmPassword: string;
  passwordError: boolean;

  constructor(public LoginService: LoginService) { }

  ngOnInit(): void {
  }

  register() {
    console.log(this.email);
    console.log(this.password);

  }
}
