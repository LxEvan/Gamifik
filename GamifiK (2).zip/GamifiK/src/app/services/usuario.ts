
export class Usuario {
    constructor(
        public nombre: string,
        public password: string,
        public email: number,
        public id?: number,
    ) { }

}