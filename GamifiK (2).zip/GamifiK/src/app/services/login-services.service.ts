import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Usuario } from "./usuario"
import { Observable } from "rxjs/Observable";
import { CookieService } from "ngx-cookie-service";
import { User } from '../models/user';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: "root"
})
export class LoginService {
  constructor(private http: HttpClient,private cookies: CookieService) {}

  setToken(token: String) {
    this.cookies.set("token", "token");
  }
  getToken() {
    return this.cookies.get("token");
  }
  getUsuario(id: string | number) {
    return this.http.get(`../Registro-bd/get.php?idUsuarios=${id}`);
  }

  addUsuario(usuario: Usuario) {
    return this.http.post(`C:/Users/Cristian/Desktop/GamifiK/src/app/Registro-bd/post.php`, JSON.stringify(usuario));
  }

  deleteUsuario(usuario: Usuario) {
    return this.http.delete(`../Registro-bd/delete.php?idUsuarios=${usuario.id}`);
  }

  updateUsuario(usuario: Usuario) {
    return this.http.put(`../Registro-bd/update.php`, usuario);
  }
  public registrealumne(sesion: any): Observable<any> {
    return this.http.post('$(environment.serverUrl)get.php',JSON.stringify(sesion))
  }

  public login(user) {
    return this.http.post<User>('http://localhost' + '/register.php', JSON.stringify(user))
    }
}
