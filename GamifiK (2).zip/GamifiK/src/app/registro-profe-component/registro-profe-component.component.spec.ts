import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistroProfeComponentComponent } from './registro-profe-component.component';

describe('RegistroProfeComponentComponent', () => {
  let component: RegistroProfeComponentComponent;
  let fixture: ComponentFixture<RegistroProfeComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegistroProfeComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistroProfeComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
