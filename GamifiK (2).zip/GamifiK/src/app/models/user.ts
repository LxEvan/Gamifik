export class User{
  nombre: String;
  password: String;
}
