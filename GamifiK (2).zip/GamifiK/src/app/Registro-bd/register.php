<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
header('Content-Type: application/json');

$postdata = file_get_contents("php://input"); // Esto es un JSON en formato string
$params = json_decode($postdata, true);	// Convertimos el JSON string que nos llega en un objeto de PHP

$password = $params['password'];
echo '{ "password": "'. $password .'" }'; // Desde el servidor tenemos que devolver siempre la información en forma de JSON

// echo  ($postdata);
?>
