import { Component, OnInit } from '@angular/core';
import { first } from 'rxjs/operators';
import { User } from '../models/user';
import { LoginService } from "../services/login-services.service";

@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',
  styleUrls: ['./login-component.component.css']
})
export class LoginComponentComponent implements OnInit {

  service: LoginService;
  user = new User();


  constructor(private LoginService: LoginService) { }


  ngOnInit(): void {

    }

    login() {
      console.log(this.user);
      this.LoginService.login(this.user)
      .pipe(first())
      .subscribe(
        (data) => {
          console.log(data)
          console.log(data['nombre'])
          console.log(data['password'])

        }
      )
    }






}
